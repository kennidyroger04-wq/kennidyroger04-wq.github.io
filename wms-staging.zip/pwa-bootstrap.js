(() => {
  'use strict';
  const VERSION = '2a72bf7722fe6fe2';
  const params = new URLSearchParams(location.search);
  if ((navigator.standalone || window.matchMedia('(display-mode: standalone)').matches) &&
      !params.has('mobile') && !params.has('cotacao')) {
    params.set('mobile', 'true');
    history.replaceState(null, '', location.pathname + '?' + params.toString() + location.hash);
  }
  const badge = document.createElement('div');
  badge.id = 'wms-pwa-status';
  badge.textContent = 'STAGING';
  badge.dataset.version = VERSION;
  badge.style.cssText = 'position:fixed;right:8px;top:max(4px,env(safe-area-inset-top));z-index:10000;pointer-events:none;background:#0f172a;color:#fff;font:10px system-ui;padding:3px 6px;border-radius:4px;';
  document.addEventListener('DOMContentLoaded', () => document.body.appendChild(badge), {once:true});
  const showUpdate = () => {
    badge.dataset.update = 'waiting';
    badge.textContent = 'STAGING · Nova versão: reabra ou recarregue quando terminar';
    badge.setAttribute('role', 'status');
  };
  if (!('serviceWorker' in navigator)) return;
  window.addEventListener('load', async () => {
    try {
      const registration = await navigator.serviceWorker.register('/sw.js', {scope:'/', updateViaCache:'none'});
      badge.dataset.serviceWorker = 'registered';
      // Only a worker already waiting at page startup can activate here.
      // A worker discovered during this session waits; it never reloads the app.
      if (registration.waiting) registration.waiting.postMessage({type:'ACTIVATE_ON_REOPEN'});
      registration.addEventListener('updatefound', () => {
        const worker = registration.installing;
        if (worker) worker.addEventListener('statechange', () => {
          if (worker.state === 'installed' && navigator.serviceWorker.controller) showUpdate();
        });
      });
      let lastCheck = 0;
      const check = () => {
        if (document.visibilityState !== 'visible' || Date.now() - lastCheck < 60000) return;
        lastCheck = Date.now();
        registration.update().catch(() => {});
      };
      document.addEventListener('visibilitychange', check);
      window.addEventListener('focus', check);
      check();
    } catch (_) {
      badge.dataset.serviceWorker = 'unavailable';
      badge.title = 'Instalação/cache indisponível. O WMS continua acessível online.';
    }
  }, {once:true});
})();
